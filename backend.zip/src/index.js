const express = require("express");
const path = require("path");
const { createServer } = require("http");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { env } = require("./config/env");
const { connectDB } = require("./config/db");
const { DEFAULT_PLANS } = require("./config/plans");
const { initSocket } = require("./socket");
const authRoutes = require("./routes/auth");
const userRoutes = require("./routes/user");
const { checkoutRouter, webhookRouter, validateDiscountCodeRouter } = require("./routes/payments");
const adminRoutes = require("./routes/admin");
const podcastRoutes = require("./routes/podcast");
const drillRoutes = require("./routes/drill");
const workoutRoutes = require("./routes/workout");
const planRoutes = require("./routes/plans");
const settingsRoutes = require("./routes/settings");
const chatRoutes = require("./routes/chat");
const Plan = require("./models/Plan");
const DiscountCode = require("./models/DiscountCode");
const Notification = require("./models/Notification");
const { deliverCampaign } = require("./services/notifications");

const app = express();
const httpServer = createServer(app);

app.set("trust proxy", 1);

app.use(
  helmet({
    contentSecurityPolicy: false,
    crossOriginResourcePolicy: { policy: "cross-origin" },
  })
);

app.use(
  cors({
    origin: true,
    credentials: true,
  })
);

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 500,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiter);

app.use("/api/webhooks", webhookRouter);

app.use(express.json({ strict: false }));

app.use("/uploads", express.static(path.resolve(__dirname, "../uploads")));

app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/payments", checkoutRouter);
app.use("/api/payments/discount", validateDiscountCodeRouter);
app.use("/api/admin", adminRoutes);
app.use("/api/podcasts", podcastRoutes);
app.use("/api/drills", drillRoutes);
app.use("/api/workouts", workoutRoutes);
app.use("/api/plans", planRoutes);
app.use("/api/settings", settingsRoutes);
app.use("/api/chat", chatRoutes);

app.get("/payment-success", (_req, res) => {
  res.send(`<!DOCTYPE html><html><head><title>Payment Successful</title><style>body{background:#000;color:#fff;font-family:sans-serif;display:flex;justify-content:center;align-items:center;height:100vh;margin:0}div{text-align:center}h1{color:#E50914}p{color:#aaa}</style></head><body><div><h1>Payment Successful!</h1><p>You can close this tab and return to the app.</p><p>Your subscription will be activated automatically.</p></div></body></html>`);
});

app.get("/payment-cancel", (_req, res) => {
  res.send(`<!DOCTYPE html><html><head><title>Payment Cancelled</title><style>body{background:#000;color:#fff;font-family:sans-serif;display:flex;justify-content:center;align-items:center;height:100vh;margin:0}div{text-align:center}h1{color:#aaa}p{color:#666}</style></head><body><div><h1>Payment Cancelled</h1><p>You can close this tab and return to the app.</p></div></body></html>`);
});

app.use((_req, res) => {
  res.status(404).json({ error: "Route not found" });
});

const { errorHandler } = require("./middleware/errorHandler");
app.use(errorHandler);

initSocket(httpServer);

async function seedPlans() {
  for (const key of Object.keys(DEFAULT_PLANS)) {
    const defaults = DEFAULT_PLANS[key];
    const existing = await Plan.findOne({ key });
    if (!existing) {
      await Plan.create(defaults);
      continue;
    }
    let changed = false;
    if (!existing.label) {
      existing.label = defaults.label;
      changed = true;
    }
    if (!existing.benefits || !existing.benefits.length) {
      existing.benefits = defaults.benefits;
      changed = true;
    }
    if (changed) await existing.save();
  }
}

async function seedDiscountCodes() {
  const discountCodes = [
    { code: "COOP20", discountAmount: 5, applicablePlan: "annual" },
    { code: "REDSHOE85", discountAmount: 5, applicablePlan: "annual" },
    { code: "CA10", discountAmount: 5, applicablePlan: "annual" },
    { code: "DESTBO", discountAmount: 5, applicablePlan: "annual" },
    { code: "JKENT20", discountAmount: 5, applicablePlan: "annual" },
    { code: "LW3", discountAmount: 5, applicablePlan: "annual" },
  ];

  for (const cd of discountCodes) {
    const existing = await DiscountCode.findOne({ code: cd.code });
    if (!existing) {
      await DiscountCode.create({ ...cd, active: true });
      console.log(`Discount code seeded: ${cd.code}`);
    }
  }
}

async function processScheduledNotifications() {
  try {
    const due = await Notification.find({
      status: "scheduled",
      scheduledAt: { $lte: new Date() },
    });
    for (const campaign of due) {
      try {
        console.log(`Sending scheduled notification: ${campaign.title}`);
        await deliverCampaign(campaign);
      } catch (error) {
        console.error("Scheduled notification failed:", error);
        campaign.status = "failed";
        campaign.error = error.message || "Delivery failed";
        await campaign.save().catch(() => {});
      }
    }
  } catch (error) {
    console.error("Scheduled notifications scan error:", error);
  }
}

async function start() {
  await connectDB();
  await seedPlans();
  await seedDiscountCodes();

  httpServer.listen(env.port, () => {
    console.log(`Server running on port ${env.port} in ${env.nodeEnv} mode`);
  });

  processScheduledNotifications();
  setInterval(processScheduledNotifications, 60 * 1000);
}

start().catch(console.error);
