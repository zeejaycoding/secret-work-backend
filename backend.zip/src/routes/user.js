const { Router } = require("express");
const bcrypt = require("bcryptjs");
const { User } = require("../models/User");
const { authMiddleware } = require("../middleware/auth");
const { upload, deleteCloudinaryFile } = require("../middleware/upload");
const Pro = require("../models/Pro");
const Drill = require("../models/Drill");
const Program = require("../models/Program");
const Follow = require("../models/Follow");
const UserNotification = require("../models/UserNotification");
const { recordActivity } = require("../services/activity");

const router = Router();

// ── Pros: Public List ──
router.get("/pros", async (req, res) => {
  try {
    const pros = await Pro.find().sort({ createdAt: -1 });
    res.json({ pros });
  } catch (error) {
    console.error("List pros error:", error);
    res.status(500).json({ error: "Failed to fetch pros" });
  }
});

router.use(authMiddleware);

router.get("/me", async (req, res) => {
  try {
    const user = await User.findById(req.auth.userId);

    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    res.json({ user });
  } catch (error) {
    console.error("Get user error:", error);
    res.status(500).json({ error: "Failed to get user" });
  }
});

router.patch("/me", async (req, res) => {
  try {
    const allowedFields = [
      "firstName",
      "lastName",
      "avatarUrl",
      "onboarded",
      "onboardingStep",
      "height",
      "heightUnit",
      "experienceLevel",
      "trainingGoal",
      "age",
      "gender",
    ];

    const updates = {};
    for (const field of allowedFields) {
      if (req.body[field] !== undefined) {
        updates[field] = req.body[field];
      }
    }

    const user = await User.findByIdAndUpdate(
      req.auth.userId,
      { $set: updates },
      { new: true, runValidators: true }
    );

    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    res.json({ user });
  } catch (error) {
    console.error("Update user error:", error);
    res.status(500).json({ error: "Failed to update user" });
  }
});

// ── Profile picture: upload (set/replace) ──
router.post("/me/avatar", upload.single("profile"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No profile image uploaded" });
    }

    const user = await User.findById(req.auth.userId);
    if (!user) {
      deleteCloudinaryFile(req.file.path);
      return res.status(404).json({ error: "User not found" });
    }

    // Replace the existing avatar, removing the previous file.
    if (user.avatarUrl) {
      deleteCloudinaryFile(user.avatarUrl);
    }

    user.avatarUrl = req.file.path;
    await user.save();

    res.json({ user });
  } catch (error) {
    console.error("Upload avatar error:", error);
    if (req.file && req.file.path) deleteCloudinaryFile(req.file.path);
    res.status(500).json({ error: "Failed to upload profile image" });
  }
});

// ── Profile picture: delete ──
router.delete("/me/avatar", async (req, res) => {
  try {
    const user = await User.findById(req.auth.userId);

    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    if (user.avatarUrl) {
      deleteCloudinaryFile(user.avatarUrl);
      user.avatarUrl = undefined;
      await user.save();
    }

    res.json({ user });
  } catch (error) {
    console.error("Delete avatar error:", error);
    res.status(500).json({ error: "Failed to delete profile image" });
  }
});

router.post("/onboarding/complete", async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.auth.userId,
      { $set: { onboarded: true } },
      { new: true }
    );

    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    res.json({ user });
  } catch (error) {
    console.error("Complete onboarding error:", error);
    res.status(500).json({ error: "Failed to complete onboarding" });
  }
});

// ── User Preferences (app preferences + playback settings) ──
router.get("/preferences", async (req, res) => {
  try {
    const user = await User.findById(req.auth.userId).select("preferences");

    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    res.json({ preferences: user.preferences || {} });
  } catch (error) {
    console.error("Get preferences error:", error);
    res.status(500).json({ error: "Failed to fetch preferences" });
  }
});

router.patch("/preferences", async (req, res) => {
  try {
    const allowedFields = [
      "darkMode",
      "language",
      "autoplayVideos",
      "dataSaver",
      "videoQuality",
      "notifications",
    ];

    const updates = {};
    for (const field of allowedFields) {
      if (req.body[field] !== undefined) {
        updates[`preferences.${field}`] = req.body[field];
      }
    }

    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ error: "No valid preference fields provided" });
    }

    const user = await User.findByIdAndUpdate(
      req.auth.userId,
      { $set: updates },
      { new: true, runValidators: true }
    ).select("preferences");

    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    res.json({ preferences: user.preferences });
  } catch (error) {
    console.error("Update preferences error:", error);
    res.status(500).json({ error: "Failed to update preferences" });
  }
});

// ── Follow a coach (by coach name) ──
router.post("/follows", async (req, res) => {
  try {
    const coach = String(req.body.coach || "").trim();
    if (!coach) {
      return res.status(400).json({ error: "coach is required" });
    }

    const existing = await Follow.findOne({ user: req.auth.userId, coach });
    let following;
    if (existing) {
      await Follow.deleteOne({ _id: existing._id });
      following = false;
    } else {
      await Follow.create({ user: req.auth.userId, coach });
      following = true;
    }

    const followers = await Follow.countDocuments({ coach });
    res.json({ success: true, following, followers });
  } catch (error) {
    console.error("Toggle follow error:", error);
    res.status(500).json({ error: "Failed to toggle follow" });
  }
});

// ── Follow status for a coach ──
router.get("/follows/status", async (req, res) => {
  try {
    const coach = String(req.query.coach || "").trim();
    if (!coach) {
      return res.status(400).json({ error: "coach is required" });
    }

    const existing = await Follow.findOne({ user: req.auth.userId, coach });
    const followers = await Follow.countDocuments({ coach });
    res.json({ following: !!existing, followers });
  } catch (error) {
    console.error("Follow status error:", error);
    res.status(500).json({ error: "Failed to fetch follow status" });
  }
});

// ── Drill Completion History ──
router.post("/progress/completed-drills", async (req, res) => {
  try {
    const { drillId } = req.body;
    if (!drillId) {
      return res.status(400).json({ error: "drillId is required" });
    }

    const drill = await Drill.findById(drillId);
    if (!drill) {
      return res.status(404).json({ error: "Drill not found" });
    }

    const user = await User.findByIdAndUpdate(
      req.auth.userId,
      { $addToSet: { completedDrills: drillId } },
      { new: true }
    );
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    await recordActivity(req.auth.userId, "drill");

    res.json({ success: true, completedDrills: user.completedDrills });
  } catch (error) {
    console.error("Record drill completion error:", error);
    res.status(500).json({ error: "Failed to record drill completion" });
  }
});

// ── Watch Time Tracking (per user, from the app players) ──
router.post("/progress/watch", async (req, res) => {
  try {
    const seconds = Number(req.body.seconds);
    if (!Number.isFinite(seconds) || seconds <= 0) {
      return res.status(400).json({ error: "seconds is required and must be positive" });
    }

    const clamped = Math.min(Math.round(seconds), 7200);

    const user = await User.findByIdAndUpdate(
      req.auth.userId,
      { $inc: { watchTimeSec: clamped } },
      { new: true }
    );
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    const drillId = req.body.drillId;
    if (drillId && /^[0-9a-fA-F]{24}$/.test(String(drillId))) {
      await Drill.updateOne(
        { _id: drillId },
        { $inc: { avgWatchSec: clamped } }
      ).catch((error) =>
        console.error("Accumulate drill watch time error:", error.message || error)
      );
    }

    await recordActivity(req.auth.userId, "watch");

    res.json({ success: true, watchTimeSec: user.watchTimeSec });
  } catch (error) {
    console.error("Record watch time error:", error);
    res.status(500).json({ error: "Failed to record watch time" });
  }
});

// ── Program Enrollment ──
router.post("/programs/enroll", async (req, res) => {
  try {
    const { programId } = req.body;
    if (!programId) {
      return res.status(400).json({ error: "programId is required" });
    }

    const program = await Program.findById(programId);
    if (!program) {
      return res.status(404).json({ error: "Program not found" });
    }

    const user = await User.findById(req.auth.userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    const alreadyEnrolled = user.enrolledPrograms.some(
      (p) => String(p) === String(programId)
    );
    if (!alreadyEnrolled) {
      user.enrolledPrograms.push(programId);
      await user.save();
      await Program.updateOne({ _id: programId }, { $inc: { enrolled: 1 } });
    }

    await recordActivity(req.auth.userId, "program");

    res.json({ success: true, enrolledPrograms: user.enrolledPrograms });
  } catch (error) {
    console.error("Enroll in program error:", error);
    res.status(500).json({ error: "Failed to enroll in program" });
  }
});

router.delete("/me", async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.auth.userId);

    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    console.log(`User deleted: ${user.email}`);
    res.json({ success: true });
  } catch (error) {
    console.error("Delete user error:", error);
    res.status(500).json({ error: "Failed to delete user" });
  }
});

router.post("/password", async (req, res) => {
  try {
    const { password } = req.body;

    if (!password || password.length < 6) {
      res.status(400).json({ error: "Password must be at least 6 characters" });
      return;
    }

    const hashed = await bcrypt.hash(password, 10);

    const user = await User.findByIdAndUpdate(
      req.auth.userId,
      { $set: { password: hashed } },
      { new: true }
    );

    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    console.log(`Password set for user: ${user.email}`);
    res.json({ success: true });
  } catch (error) {
    console.error("Set password error:", error);
    res.status(500).json({ error: "Failed to set password" });
  }
});

router.post("/password/change", async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body;

    if (!oldPassword || !newPassword) {
      res.status(400).json({ error: "Old password and new password are required" });
      return;
    }

    if (newPassword.length < 8) {
      res.status(400).json({ error: "New password must be at least 8 characters" });
      return;
    }

    const user = await User.findById(req.auth.userId);

    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    if (!user.password) {
      res.status(400).json({ error: "No password set. Use 'Forgot Password' to set one." });
      return;
    }

    const valid = await bcrypt.compare(oldPassword, user.password);
    if (!valid) {
      res.status(401).json({ error: "Current password is incorrect" });
      return;
    }

    user.password = await bcrypt.hash(newPassword, 10);
    await user.save();

    console.log(`Password changed for user: ${user.email}`);
    res.json({ success: true, message: "Password changed successfully" });
  } catch (error) {
    console.error("Change password error:", error);
    res.status(500).json({ error: "Failed to change password" });
  }
});

// ── Notifications ──
router.get("/notifications", async (req, res) => {
  try {
    const notifications = await UserNotification.find({ userId: req.auth.userId })
      .sort({ createdAt: -1 })
      .limit(50);
    res.json({ notifications });
  } catch (error) {
    console.error("List user notifications error:", error);
    res.status(500).json({ error: "Failed to fetch notifications" });
  }
});

router.get("/notifications/unread-count", async (req, res) => {
  try {
    const count = await UserNotification.countDocuments({
      userId: req.auth.userId,
      read: false,
    });
    res.json({ count });
  } catch (error) {
    console.error("Unread count error:", error);
    res.status(500).json({ error: "Failed to fetch unread count" });
  }
});

router.patch("/notifications/:id/read", async (req, res) => {
  try {
    await UserNotification.updateOne(
      { _id: req.params.id, userId: req.auth.userId },
      { read: true, readAt: new Date() }
    );
    res.json({ success: true });
  } catch (error) {
    console.error("Mark notification read error:", error);
    res.status(500).json({ error: "Failed to mark notification read" });
  }
});

router.post("/notifications/read-all", async (req, res) => {
  try {
    await UserNotification.updateMany(
      { userId: req.auth.userId, read: false },
      { read: true, readAt: new Date() }
    );
    res.json({ success: true });
  } catch (error) {
    console.error("Read all notifications error:", error);
    res.status(500).json({ error: "Failed to mark notifications read" });
  }
});

// ── Push token ──
router.post("/push-token", async (req, res) => {
  try {
    const token = String(req.body?.token || "").trim();
    if (!token) {
      return res.status(400).json({ error: "Push token is required" });
    }
    await User.updateOne({ _id: req.auth.userId }, { pushToken: token });
    res.json({ success: true });
  } catch (error) {
    console.error("Save push token error:", error);
    res.status(500).json({ error: "Failed to save push token" });
  }
});

// ── Notification preferences ──
router.get("/notification-prefs", async (req, res) => {
  try {
    const user = await User.findById(req.auth.userId).select("notificationPrefs");
    res.json({
      prefs: user?.notificationPrefs || { push: true, email: true, inApp: true },
    });
  } catch (error) {
    console.error("Get notification prefs error:", error);
    res.status(500).json({ error: "Failed to fetch preferences" });
  }
});

router.post("/notification-prefs", async (req, res) => {
  try {
    const incoming = req.body?.prefs || {};
    const clean = {
      push: incoming.push !== false,
      email: incoming.email !== false,
      inApp: incoming.inApp !== false,
    };
    await User.updateOne({ _id: req.auth.userId }, { notificationPrefs: clean });
    res.json({ prefs: clean });
  } catch (error) {
    console.error("Save notification prefs error:", error);
    res.status(500).json({ error: "Failed to save preferences" });
  }
});

module.exports = router;
