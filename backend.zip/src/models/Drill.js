const mongoose = require("mongoose");

const drillSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, default: "" },
    coach: { type: String, trim: true },
    proId: { type: mongoose.Schema.Types.ObjectId, ref: "Pro", default: null },
    category: { type: String, default: "Dribbling", trim: true },
    level: {
      type: String,
      enum: ["Beginner", "Intermediate", "Advanced"],
      default: "Beginner",
    },
    equipment: {
      type: String,
      default: "Dumbell",
    },
    status: {
      type: String,
      enum: ["published", "draft", "archived"],
      default: "draft",
    },
    imageUrl: { type: String, default: "" },
    videoUrl: { type: String, default: "" },
    duration: { type: String, default: "0 min" },
    views: { type: Number, default: 0 },
    likes: { type: Number, default: 0 },
    completionRate: { type: Number, default: 0 },
    avgWatchTime: { type: String, default: "0 min" },
    avgWatchSec: { type: Number, default: 0 },
    viewsHistory: [
      {
        date: { type: Date },
        count: { type: Number, default: 0 },
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model("Drill", drillSchema);
